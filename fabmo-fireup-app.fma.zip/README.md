# Handibot Fire-Up! App

## About
This Apps will help you get your Handibot ready for work each day. There are Push-Buttons to Zero the Axes and do other Jobs, as well as instructive details on using your Handibot.

## Online Availability
The latest version of the example app is always available to try out here: https://github.com/FabMo/fabmo-fireup-app/releases

